# frozen_string_literal: true

# app/helpers/application_helper.rb
module ApplicationHelper
end
