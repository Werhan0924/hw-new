# frozen_string_literal: true

# Load the rails application
require File.expand_path('application', __dir__)

# Initialize the rails application
Rottenpotatoes::Application.initialize!
