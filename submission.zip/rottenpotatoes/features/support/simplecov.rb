# frozen_string_literal: true

require 'simplecov'
SimpleCov.start 'rails'
